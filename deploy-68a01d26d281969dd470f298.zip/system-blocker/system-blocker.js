const { exec, spawn } = require('child_process');
const express = require('express');
const cors = require('cors');
const fs = require('fs-extra');
const path = require('path');
const chalk = require('chalk');

// System-level ad blocking for Windows applications
class SystemAdBlocker {
  constructor() {
    this.blockedProcesses = new Set([
      'spotify.exe',
      'discord.exe',
      'steam.exe',
      'epicgameslauncher.exe',
      'origin.exe',
      'uplay.exe',
      'battlenet.exe',
      'riotclientservices.exe',
      'valorant.exe',
      'fortnite.exe',
      'minecraft.exe'
    ]);
    
    this.blockedHosts = [
      // Spotify ads
      '0.0.0.0 adeventtracker.spotify.com',
      '0.0.0.0 ads-fa.spotify.com',
      '0.0.0.0 analytics.spotify.com',
      '0.0.0.0 audio-ak-spotify-com.akamaized.net',
      '0.0.0.0 crashdump.spotify.com',
      '0.0.0.0 log.spotify.com',
      '0.0.0.0 omaze.spotify.com',
      '0.0.0.0 pubads.g.doubleclick.net',
      '0.0.0.0 securepubads.g.doubleclick.net',
      
      // Gaming ads
      '0.0.0.0 ads.steampowered.com',
      '0.0.0.0 steamcommunity-a.akamaihd.net',
      '0.0.0.0 tracking.epicgames.com',
      '0.0.0.0 analytics.epicgames.com',
      '0.0.0.0 telemetry.epicgames.com',
      
      // Discord ads
      '0.0.0.0 gateway.discord.gg',
      '0.0.0.0 analytics.discord.com',
      
      // General ad networks
      '0.0.0.0 doubleclick.net',
      '0.0.0.0 googleadservices.com',
      '0.0.0.0 googlesyndication.com',
      '0.0.0.0 amazon-adsystem.com',
      '0.0.0.0 facebook.com',
      '0.0.0.0 google-analytics.com'
    ];
    
    this.stats = {
      blockedConnections: 0,
      blockedProcesses: 0,
      startTime: Date.now()
    };
  }

  async start() {
    console.log(chalk.green('🛡️  Starting CrossGuard System Blocker...'));
    
    // Modify hosts file
    await this.updateHostsFile();
    
    // Set up Windows Firewall rules
    await this.setupFirewallRules();
    
    // Monitor processes
    this.startProcessMonitoring();
    
    // Start HTTP API
    this.startAPI();
    
    console.log(chalk.green('✅ System-level ad blocking active!'));
  }

  async updateHostsFile() {
    try {
      const hostsPath = 'C:\\Windows\\System32\\drivers\\etc\\hosts';
      const backupPath = 'C:\\Windows\\System32\\drivers\\etc\\hosts.crossguard.backup';
      
      // Create backup
      if (!await fs.exists(backupPath)) {
        await fs.copy(hostsPath, backupPath);
        console.log(chalk.blue('📋 Created hosts file backup'));
      }
      
      // Read current hosts file
      let hostsContent = await fs.readFile(hostsPath, 'utf8');
      
      // Remove existing CrossGuard entries
      hostsContent = hostsContent.replace(/# CrossGuard Start[\s\S]*?# CrossGuard End\n?/g, '');
      
      // Add CrossGuard entries
      const crossguardEntries = [
        '\n# CrossGuard Start - Ad Blocking Entries',
        ...this.blockedHosts,
        '# CrossGuard End\n'
      ].join('\n');
      
      hostsContent += crossguardEntries;
      
      // Write updated hosts file
      await fs.writeFile(hostsPath, hostsContent);
      console.log(chalk.green(`✅ Updated hosts file with ${this.blockedHosts.length} blocked domains`));
      
    } catch (error) {
      console.error(chalk.red(`❌ Failed to update hosts file: ${error.message}`));
      console.log(chalk.yellow('⚠️  Run as Administrator to modify hosts file'));
    }
  }

  async setupFirewallRules() {
    try {
      // Block outbound connections to ad servers for specific processes
      for (const process of this.blockedProcesses) {
        const ruleName = `CrossGuard_Block_${process}`;
        
        // Remove existing rule if it exists
        exec(`netsh advfirewall firewall delete rule name="${ruleName}"`, () => {});
        
        // Add new blocking rule
        const command = `netsh advfirewall firewall add rule name="${ruleName}" dir=out action=block program="C:\\Program Files\\*\\${process}" enable=yes`;
        
        exec(command, (error, stdout, stderr) => {
          if (!error) {
            console.log(chalk.green(`✅ Added firewall rule for ${process}`));
          }
        });
      }
      
    } catch (error) {
      console.error(chalk.red(`❌ Failed to setup firewall rules: ${error.message}`));
    }
  }

  startProcessMonitoring() {
    // Monitor running processes and block ad-related network connections
    setInterval(() => {
      exec('tasklist /fo csv', (error, stdout, stderr) => {
        if (!error) {
          const processes = stdout.split('\n').slice(1);
          
          processes.forEach(line => {
            const parts = line.split('","');
            if (parts.length > 0) {
              const processName = parts[0].replace(/"/g, '').toLowerCase();
              
              if (this.blockedProcesses.has(processName)) {
                this.stats.blockedProcesses++;
                // Additional process-specific blocking logic can be added here
              }
            }
          });
        }
      });
    }, 10000); // Check every 10 seconds
  }

  startAPI() {
    const app = express();
    app.use(cors());
    app.use(express.json());

    app.get('/api/system-stats', (req, res) => {
      res.json({
        blockedConnections: this.stats.blockedConnections,
        blockedProcesses: this.stats.blockedProcesses,
        monitoredProcesses: Array.from(this.blockedProcesses),
        blockedHosts: this.blockedHosts.length,
        uptime: Date.now() - this.stats.startTime
      });
    });

    app.post('/api/add-process', (req, res) => {
      const { processName } = req.body;
      if (processName) {
        this.blockedProcesses.add(processName.toLowerCase());
        res.json({ success: true, message: `Added ${processName} to blocked processes` });
      } else {
        res.status(400).json({ success: false, message: 'Process name required' });
      }
    });

    app.delete('/api/remove-process/:process', (req, res) => {
      const processName = req.params.process.toLowerCase();
      this.blockedProcesses.delete(processName);
      res.json({ success: true, message: `Removed ${processName} from blocked processes` });
    });

    app.listen(3002, () => {
      console.log(chalk.blue('🌐 System Blocker API running on http://localhost:3002'));
    });
  }

  async cleanup() {
    try {
      // Restore original hosts file
      const hostsPath = 'C:\\Windows\\System32\\drivers\\etc\\hosts';
      const backupPath = 'C:\\Windows\\System32\\drivers\\etc\\hosts.crossguard.backup';
      
      if (await fs.exists(backupPath)) {
        await fs.copy(backupPath, hostsPath);
        await fs.remove(backupPath);
        console.log(chalk.green('✅ Restored original hosts file'));
      }
      
      // Remove firewall rules
      for (const process of this.blockedProcesses) {
        const ruleName = `CrossGuard_Block_${process}`;
        exec(`netsh advfirewall firewall delete rule name="${ruleName}"`, () => {});
      }
      
      console.log(chalk.green('✅ Cleanup completed'));
      
    } catch (error) {
      console.error(chalk.red(`❌ Cleanup failed: ${error.message}`));
    }
  }
}

// Start the system blocker
const systemBlocker = new SystemAdBlocker();

// Graceful shutdown
process.on('SIGINT', async () => {
  console.log(chalk.yellow('\n🛑 Shutting down System Blocker...'));
  await systemBlocker.cleanup();
  process.exit(0);
});

process.on('SIGTERM', async () => {
  console.log(chalk.yellow('\n🛑 Shutting down System Blocker...'));
  await systemBlocker.cleanup();
  process.exit(0);
});

// Start the blocker
systemBlocker.start().catch(error => {
  console.error(chalk.red(`❌ Failed to start System Blocker: ${error.message}`));
  process.exit(1);
});
