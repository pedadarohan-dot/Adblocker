import React, { useState, useEffect } from 'react';
import { Shield, Settings, BarChart3, List, Globe, Smartphone, Monitor, Wifi } from 'lucide-react';
import { mockApi, isTauri } from './mockApi';
import Dashboard from './components/Dashboard';
import BlocklistManager from './components/BlocklistManager';
import SettingsPanel from './components/SettingsPanel';
import StatsView from './components/StatsView';

interface AdBlockerConfig {
  dns_enabled: boolean;
  browser_extension_enabled: boolean;
  system_blocking_enabled: boolean;
  streaming_blocking_enabled: boolean;
  auto_update_enabled: boolean;
  blocked_domains: Array<{
    domain: string;
    category: string;
    blocked_count: number;
    last_blocked: string;
  }>;
  whitelist: Array<{
    domain: string;
    added_date: string;
    reason: string;
  }>;
}

type TabType = 'dashboard' | 'blocklist' | 'settings' | 'stats';

function App() {
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  const [config, setConfig] = useState<AdBlockerConfig | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadConfig();
  }, []);

  const loadConfig = async () => {
    try {
      let configData: AdBlockerConfig;
      if (isTauri()) {
        const { invoke } = await import('@tauri-apps/api/tauri');
        configData = await invoke<AdBlockerConfig>('get_config');
      } else {
        configData = await mockApi.get_config();
      }
      setConfig(configData);
    } catch (error) {
      console.error('Failed to load config:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateConfig = async (newConfig: AdBlockerConfig) => {
    try {
      if (isTauri()) {
        const { invoke } = await import('@tauri-apps/api/tauri');
        await invoke('update_config', { newConfig });
      } else {
        await mockApi.update_config(newConfig);
      }
      setConfig(newConfig);
    } catch (error) {
      console.error('Failed to update config:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Shield className="w-16 h-16 text-primary-500 mx-auto mb-4 animate-pulse" />
          <p className="text-gray-600">Loading CrossGuard...</p>
        </div>
      </div>
    );
  }

  const tabs = [
    { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
    { id: 'blocklist', label: 'Blocklist', icon: List },
    { id: 'settings', label: 'Settings', icon: Settings },
    { id: 'stats', label: 'Statistics', icon: Globe },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Shield className="w-8 h-8 text-primary-500" />
              <div>
                <h1 className="text-xl font-bold text-gray-900">CrossGuard</h1>
                <p className="text-sm text-gray-500">Universal Ad Blocker</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              {config && (
                <>
                  <div className="flex items-center space-x-2">
                    <Wifi className={`w-4 h-4 ${config.dns_enabled ? 'text-success-500' : 'text-gray-400'}`} />
                    <span className="text-sm text-gray-600">DNS</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Monitor className={`w-4 h-4 ${config.browser_extension_enabled ? 'text-success-500' : 'text-gray-400'}`} />
                    <span className="text-sm text-gray-600">Browser</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Smartphone className={`w-4 h-4 ${config.streaming_blocking_enabled ? 'text-success-500' : 'text-gray-400'}`} />
                    <span className="text-sm text-gray-600">Streaming</span>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <nav className="w-64 bg-white shadow-sm min-h-screen">
          <div className="p-4">
            <div className="space-y-2">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as TabType)}
                    className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors ${
                      activeTab === tab.id
                        ? 'bg-primary-50 text-primary-700 border border-primary-200'
                        : 'text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="font-medium">{tab.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </nav>

        {/* Main Content */}
        <main className="flex-1 p-6">
          {config && (
            <>
              {activeTab === 'dashboard' && <Dashboard config={config} onConfigUpdate={updateConfig} />}
              {activeTab === 'blocklist' && <BlocklistManager config={config} onConfigUpdate={updateConfig} />}
              {activeTab === 'settings' && <SettingsPanel config={config} onConfigUpdate={updateConfig} />}
              {activeTab === 'stats' && <StatsView config={config} />}
            </>
          )}
        </main>
      </div>
    </div>
  );
}

export default App;
