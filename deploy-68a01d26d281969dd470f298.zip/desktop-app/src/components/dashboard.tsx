import React, { useState, useEffect } from 'react';
import { invoke } from '@tauri-apps/api/tauri';
import { Shield, Activity, Clock, AlertTriangle, Play, Square } from 'lucide-react';

interface DashboardProps {
  config: any;
  onConfigUpdate: (config: any) => void;
}

interface Stats {
  total_blocked: number;
  domains_blocked: number;
  whitelist_entries: number;
  [key: string]: number;
}

const Dashboard: React.FC<DashboardProps> = ({ config, onConfigUpdate }) => {
  const [stats, setStats] = useState<Stats | null>(null);
  const [dnsStatus, setDnsStatus] = useState<'stopped' | 'running' | 'starting' | 'stopping'>('stopped');
  const [updating, setUpdating] = useState(false);

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    try {
      const statsData = await invoke<Stats>('get_blocked_stats');
      setStats(statsData);
    } catch (error) {
      console.error('Failed to load stats:', error);
    }
  };

  const toggleDnsServer = async () => {
    try {
      if (dnsStatus === 'stopped') {
        setDnsStatus('starting');
        await invoke('start_dns_server');
        setDnsStatus('running');
      } else {
        setDnsStatus('stopping');
        await invoke('stop_dns_server');
        setDnsStatus('stopped');
      }
    } catch (error) {
      console.error('Failed to toggle DNS server:', error);
      setDnsStatus('stopped');
    }
  };

  const updateBlocklists = async () => {
    setUpdating(true);
    try {
      await invoke('update_blocklists');
      await loadStats();
    } catch (error) {
      console.error('Failed to update blocklists:', error);
    } finally {
      setUpdating(false);
    }
  };

  const StatCard = ({ title, value, icon: Icon, color = 'primary' }: any) => (
    <div className="bg-white rounded-lg shadow-sm border p-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-600">{title}</p>
          <p className={`text-2xl font-bold text-${color}-600`}>
            {typeof value === 'number' ? value.toLocaleString() : value}
          </p>
        </div>
        <Icon className={`w-8 h-8 text-${color}-500`} />
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Dashboard</h2>
        <div className="flex items-center space-x-3">
          <button
            onClick={updateBlocklists}
            disabled={updating}
            className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 disabled:opacity-50 flex items-center space-x-2"
          >
            <Clock className={`w-4 h-4 ${updating ? 'animate-spin' : ''}`} />
            <span>{updating ? 'Updating...' : 'Update Lists'}</span>
          </button>
          <button
            onClick={toggleDnsServer}
            disabled={dnsStatus === 'starting' || dnsStatus === 'stopping'}
            className={`px-4 py-2 rounded-lg flex items-center space-x-2 ${
              dnsStatus === 'running'
                ? 'bg-danger-600 text-white hover:bg-danger-700'
                : 'bg-success-600 text-white hover:bg-success-700'
            }`}
          >
            {dnsStatus === 'running' ? (
              <>
                <Square className="w-4 h-4" />
                <span>Stop DNS</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4" />
                <span>Start DNS</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total Ads Blocked"
          value={stats?.total_blocked || 0}
          icon={Shield}
          color="success"
        />
        <StatCard
          title="Blocked Domains"
          value={stats?.domains_blocked || 0}
          icon={AlertTriangle}
          color="warning"
        />
        <StatCard
          title="Whitelist Entries"
          value={stats?.whitelist_entries || 0}
          icon={Activity}
          color="primary"
        />
        <StatCard
          title="DNS Status"
          value={dnsStatus.charAt(0).toUpperCase() + dnsStatus.slice(1)}
          icon={Activity}
          color={dnsStatus === 'running' ? 'success' : 'danger'}
        />
      </div>

      {/* Protection Status */}
      <div className="bg-white rounded-lg shadow-sm border p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Protection Status</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <p className="font-medium text-gray-900">DNS Filtering</p>
              <p className="text-sm text-gray-600">Network-wide ad blocking</p>
            </div>
            <div className={`w-3 h-3 rounded-full ${config.dns_enabled ? 'bg-success-500' : 'bg-gray-400'}`} />
          </div>
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <p className="font-medium text-gray-900">Browser Extension</p>
              <p className="text-sm text-gray-600">Web page ad blocking</p>
            </div>
            <div className={`w-3 h-3 rounded-full ${config.browser_extension_enabled ? 'bg-success-500' : 'bg-gray-400'}`} />
          </div>
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <p className="font-medium text-gray-900">System Blocking</p>
              <p className="text-sm text-gray-600">Application-level blocking</p>
            </div>
            <div className={`w-3 h-3 rounded-full ${config.system_blocking_enabled ? 'bg-success-500' : 'bg-gray-400'}`} />
          </div>
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <p className="font-medium text-gray-900">Streaming Protection</p>
              <p className="text-sm text-gray-600">Video/audio ad blocking</p>
            </div>
            <div className={`w-3 h-3 rounded-full ${config.streaming_blocking_enabled ? 'bg-success-500' : 'bg-gray-400'}`} />
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-lg shadow-sm border p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Activity</h3>
        <div className="space-y-3">
          {config.blocked_domains.slice(0, 5).map((domain: any, index: number) => (
            <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div>
                <p className="font-medium text-gray-900">{domain.domain}</p>
                <p className="text-sm text-gray-600">{domain.category}</p>
              </div>
              <div className="text-right">
                <p className="font-medium text-danger-600">{domain.blocked_count} blocked</p>
                <p className="text-sm text-gray-600">{new Date(domain.last_blocked).toLocaleDateString()}</p>
              </div>
            </div>
          ))}
          {config.blocked_domains.length === 0 && (
            <p className="text-gray-500 text-center py-4">No recent activity</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
