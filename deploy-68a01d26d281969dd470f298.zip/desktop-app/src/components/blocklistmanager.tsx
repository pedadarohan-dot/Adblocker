import React, { useState } from 'react';
import { invoke } from '@tauri-apps/api/tauri';
import { Plus, Trash2, Search, Shield, AlertCircle } from 'lucide-react';

interface BlocklistManagerProps {
  config: any;
  onConfigUpdate: (config: any) => void;
}

const BlocklistManager: React.FC<BlocklistManagerProps> = ({ config, onConfigUpdate }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [newDomain, setNewDomain] = useState('');
  const [newReason, setNewReason] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);

  const filteredWhitelist = config.whitelist.filter((entry: any) =>
    entry.domain.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredBlockedDomains = config.blocked_domains.filter((domain: any) =>
    domain.domain.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const addToWhitelist = async () => {
    if (!newDomain.trim()) return;

    try {
      await invoke('add_to_whitelist', {
        domain: newDomain.trim(),
        reason: newReason.trim() || 'User added'
      });
      
      // Reload config
      const updatedConfig = await invoke('get_config');
      onConfigUpdate(updatedConfig);
      
      setNewDomain('');
      setNewReason('');
      setShowAddForm(false);
    } catch (error) {
      console.error('Failed to add to whitelist:', error);
    }
  };

  const removeFromWhitelist = async (domain: string) => {
    try {
      await invoke('remove_from_whitelist', { domain });
      
      // Reload config
      const updatedConfig = await invoke('get_config');
      onConfigUpdate(updatedConfig);
    } catch (error) {
      console.error('Failed to remove from whitelist:', error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Blocklist Manager</h2>
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 flex items-center space-x-2"
        >
          <Plus className="w-4 h-4" />
          <span>Add to Whitelist</span>
        </button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
        <input
          type="text"
          placeholder="Search domains..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
        />
      </div>

      {/* Add to Whitelist Form */}
      {showAddForm && (
        <div className="bg-white rounded-lg shadow-sm border p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Add Domain to Whitelist</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Domain
              </label>
              <input
                type="text"
                placeholder="example.com"
                value={newDomain}
                onChange={(e) => setNewDomain(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Reason (optional)
              </label>
              <input
                type="text"
                placeholder="Why is this domain whitelisted?"
                value={newReason}
                onChange={(e) => setNewReason(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              />
            </div>
            <div className="flex space-x-3">
              <button
                onClick={addToWhitelist}
                className="px-4 py-2 bg-success-600 text-white rounded-lg hover:bg-success-700"
              >
                Add to Whitelist
              </button>
              <button
                onClick={() => setShowAddForm(false)}
                className="px-4 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Whitelist */}
        <div className="bg-white rounded-lg shadow-sm border">
          <div className="p-6 border-b">
            <div className="flex items-center space-x-2">
              <Shield className="w-5 h-5 text-success-500" />
              <h3 className="text-lg font-semibold text-gray-900">
                Whitelist ({filteredWhitelist.length})
              </h3>
            </div>
            <p className="text-sm text-gray-600 mt-1">
              Domains that are allowed through the ad blocker
            </p>
          </div>
          <div className="max-h-96 overflow-y-auto">
            {filteredWhitelist.length > 0 ? (
              <div className="divide-y divide-gray-200">
                {filteredWhitelist.map((entry: any, index: number) => (
                  <div key={index} className="p-4 hover:bg-gray-50">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <p className="font-medium text-gray-900">{entry.domain}</p>
                        <p className="text-sm text-gray-600">{entry.reason}</p>
                        <p className="text-xs text-gray-500">
                          Added: {new Date(entry.added_date).toLocaleDateString()}
                        </p>
                      </div>
                      <button
                        onClick={() => removeFromWhitelist(entry.domain)}
                        className="p-2 text-danger-600 hover:bg-danger-50 rounded-lg"
                        title="Remove from whitelist"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-8 text-center text-gray-500">
                <Shield className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                <p>No whitelisted domains</p>
              </div>
            )}
          </div>
        </div>

        {/* Blocked Domains */}
        <div className="bg-white rounded-lg shadow-sm border">
          <div className="p-6 border-b">
            <div className="flex items-center space-x-2">
              <AlertCircle className="w-5 h-5 text-danger-500" />
              <h3 className="text-lg font-semibold text-gray-900">
                Blocked Domains ({filteredBlockedDomains.length})
              </h3>
            </div>
            <p className="text-sm text-gray-600 mt-1">
              Domains currently being blocked
            </p>
          </div>
          <div className="max-h-96 overflow-y-auto">
            {filteredBlockedDomains.length > 0 ? (
              <div className="divide-y divide-gray-200">
                {filteredBlockedDomains.map((domain: any, index: number) => (
                  <div key={index} className="p-4 hover:bg-gray-50">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <p className="font-medium text-gray-900">{domain.domain}</p>
                        <div className="flex items-center space-x-4 mt-1">
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-danger-100 text-danger-800">
                            {domain.category}
                          </span>
                          <span className="text-sm text-gray-600">
                            {domain.blocked_count} blocked
                          </span>
                        </div>
                        <p className="text-xs text-gray-500">
                          Last blocked: {new Date(domain.last_blocked).toLocaleDateString()}
                        </p>
                      </div>
                      <button
                        onClick={() => {
                          setNewDomain(domain.domain);
                          setNewReason(`Previously blocked ${domain.category} domain`);
                          setShowAddForm(true);
                        }}
                        className="p-2 text-success-600 hover:bg-success-50 rounded-lg"
                        title="Add to whitelist"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-8 text-center text-gray-500">
                <AlertCircle className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                <p>No blocked domains</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BlocklistManager;
