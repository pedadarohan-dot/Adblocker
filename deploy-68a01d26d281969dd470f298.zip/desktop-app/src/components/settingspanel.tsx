import React from 'react';
import { Toggle } from './Toggle';

interface SettingsPanelProps {
  config: any;
  onConfigUpdate: (config: any) => void;
}

const SettingsPanel: React.FC<SettingsPanelProps> = ({ config, onConfigUpdate }) => {
  const updateSetting = (key: string, value: boolean) => {
    const newConfig = { ...config, [key]: value };
    onConfigUpdate(newConfig);
  };

  const SettingGroup = ({ title, description, children }: any) => (
    <div className="bg-white rounded-lg shadow-sm border p-6">
      <div className="mb-4">
        <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
        <p className="text-sm text-gray-600">{description}</p>
      </div>
      <div className="space-y-4">
        {children}
      </div>
    </div>
  );

  const SettingItem = ({ label, description, enabled, onChange }: any) => (
    <div className="flex items-center justify-between">
      <div className="flex-1">
        <p className="font-medium text-gray-900">{label}</p>
        <p className="text-sm text-gray-600">{description}</p>
      </div>
      <Toggle enabled={enabled} onChange={onChange} />
    </div>
  );

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900">Settings</h2>

      <SettingGroup
        title="Core Protection"
        description="Configure the main ad-blocking features"
      >
        <SettingItem
          label="DNS Filtering"
          description="Block ads at the network level using DNS filtering"
          enabled={config.dns_enabled}
          onChange={(value: boolean) => updateSetting('dns_enabled', value)}
        />
        <SettingItem
          label="Browser Extension"
          description="Enable browser-based ad blocking for web pages"
          enabled={config.browser_extension_enabled}
          onChange={(value: boolean) => updateSetting('browser_extension_enabled', value)}
        />
        <SettingItem
          label="System-Level Blocking"
          description="Block ads in desktop and mobile applications"
          enabled={config.system_blocking_enabled}
          onChange={(value: boolean) => updateSetting('system_blocking_enabled', value)}
        />
      </SettingGroup>

      <SettingGroup
        title="Advanced Features"
        description="Additional blocking capabilities"
      >
        <SettingItem
          label="Streaming Platform Protection"
          description="Block ads on YouTube, Spotify, Twitch, and other streaming services"
          enabled={config.streaming_blocking_enabled}
          onChange={(value: boolean) => updateSetting('streaming_blocking_enabled', value)}
        />
        <SettingItem
          label="Automatic Updates"
          description="Automatically update ad-blocking rules and domain lists"
          enabled={config.auto_update_enabled}
          onChange={(value: boolean) => updateSetting('auto_update_enabled', value)}
        />
      </SettingGroup>

      <SettingGroup
        title="Privacy & Security"
        description="Configure privacy and security settings"
      >
        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-start space-x-3">
            <div className="flex-shrink-0">
              <svg className="w-5 h-5 text-green-500" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
              </svg>
            </div>
            <div>
              <h4 className="text-sm font-medium text-green-800">Privacy-First Design</h4>
              <p className="text-sm text-green-700 mt-1">
                CrossGuard processes all data locally on your device. No personal information is collected or transmitted to external servers.
              </p>
            </div>
          </div>
        </div>
      </SettingGroup>

      <SettingGroup
        title="Performance"
        description="Optimize blocking performance"
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="font-medium text-gray-900">Memory Usage</h4>
            <p className="text-2xl font-bold text-primary-600">~50MB</p>
            <p className="text-sm text-gray-600">Current memory footprint</p>
          </div>
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="font-medium text-gray-900">Blocked Today</h4>
            <p className="text-2xl font-bold text-success-600">
              {config.blocked_domains.reduce((sum: number, domain: any) => sum + domain.blocked_count, 0)}
            </p>
            <p className="text-sm text-gray-600">Ads and trackers blocked</p>
          </div>
        </div>
      </SettingGroup>

      <SettingGroup
        title="About"
        description="Application information"
      >
        <div className="space-y-3">
          <div className="flex justify-between">
            <span className="text-gray-600">Version</span>
            <span className="font-medium">1.0.0</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">License</span>
            <span className="font-medium">MIT</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Last Updated</span>
            <span className="font-medium">{new Date().toLocaleDateString()}</span>
          </div>
        </div>
      </SettingGroup>
    </div>
  );
};

export default SettingsPanel;
