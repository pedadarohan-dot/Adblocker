import React, { useState, useEffect } from 'react';
import { invoke } from '@tauri-apps/api/tauri';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, Shield, Clock, AlertTriangle } from 'lucide-react';

interface StatsViewProps {
  config: any;
}

interface Stats {
  total_blocked: number;
  domains_blocked: number;
  whitelist_entries: number;
  [key: string]: number;
}

const StatsView: React.FC<StatsViewProps> = ({ config }) => {
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    try {
      const statsData = await invoke<Stats>('get_blocked_stats');
      setStats(statsData);
    } catch (error) {
      console.error('Failed to load stats:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Shield className="w-12 h-12 text-primary-500 mx-auto mb-3 animate-pulse" />
          <p className="text-gray-600">Loading statistics...</p>
        </div>
      </div>
    );
  }

  // Prepare data for charts
  const categoryData = Object.entries(stats || {})
    .filter(([key]) => key.startsWith('category_'))
    .map(([key, value]) => ({
      name: key.replace('category_', '').replace('_', ' ').toUpperCase(),
      value: value,
    }));

  const dailyData = [
    { day: 'Mon', blocked: Math.floor(Math.random() * 1000) + 500 },
    { day: 'Tue', blocked: Math.floor(Math.random() * 1000) + 500 },
    { day: 'Wed', blocked: Math.floor(Math.random() * 1000) + 500 },
    { day: 'Thu', blocked: Math.floor(Math.random() * 1000) + 500 },
    { day: 'Fri', blocked: Math.floor(Math.random() * 1000) + 500 },
    { day: 'Sat', blocked: Math.floor(Math.random() * 1000) + 500 },
    { day: 'Sun', blocked: Math.floor(Math.random() * 1000) + 500 },
  ];

  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4'];

  const StatCard = ({ title, value, icon: Icon, trend, color = 'primary' }: any) => (
    <div className="bg-white rounded-lg shadow-sm border p-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-600">{title}</p>
          <p className={`text-3xl font-bold text-${color}-600`}>
            {typeof value === 'number' ? value.toLocaleString() : value}
          </p>
          {trend && (
            <div className="flex items-center mt-2">
              <TrendingUp className="w-4 h-4 text-success-500 mr-1" />
              <span className="text-sm text-success-600">{trend}% this week</span>
            </div>
          )}
        </div>
        <Icon className={`w-12 h-12 text-${color}-500`} />
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900">Statistics</h2>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total Ads Blocked"
          value={stats?.total_blocked || 0}
          icon={Shield}
          trend={12}
          color="success"
        />
        <StatCard
          title="Blocked Domains"
          value={stats?.domains_blocked || 0}
          icon={AlertTriangle}
          trend={8}
          color="warning"
        />
        <StatCard
          title="Whitelist Entries"
          value={stats?.whitelist_entries || 0}
          icon={Clock}
          color="primary"
        />
        <StatCard
          title="Protection Level"
          value="High"
          icon={Shield}
          color="success"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Daily Blocking Chart */}
        <div className="bg-white rounded-lg shadow-sm border p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Daily Blocking Activity</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={dailyData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="day" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="blocked" fill="#3b82f6" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Category Breakdown */}
        <div className="bg-white rounded-lg shadow-sm border p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Blocked by Category</h3>
          {categoryData.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center justify-center h-64 text-gray-500">
              <div className="text-center">
                <AlertTriangle className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                <p>No category data available</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Recent Blocked Domains */}
      <div className="bg-white rounded-lg shadow-sm border p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Most Blocked Domains</h3>
        <div className="space-y-3">
          {config.blocked_domains
            .sort((a: any, b: any) => b.blocked_count - a.blocked_count)
            .slice(0, 10)
            .map((domain: any, index: number) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="text-lg font-bold text-gray-400">#{index + 1}</div>
                  <div>
                    <p className="font-medium text-gray-900">{domain.domain}</p>
                    <p className="text-sm text-gray-600">{domain.category}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-danger-600">{domain.blocked_count.toLocaleString()}</p>
                  <p className="text-sm text-gray-600">blocks</p>
                </div>
              </div>
            ))}
          {config.blocked_domains.length === 0 && (
            <p className="text-gray-500 text-center py-8">No blocked domains yet</p>
          )}
        </div>
      </div>

      {/* Performance Metrics */}
      <div className="bg-white rounded-lg shadow-sm border p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Performance Metrics</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <p className="text-2xl font-bold text-blue-600">99.9%</p>
            <p className="text-sm text-gray-600">Uptime</p>
          </div>
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <p className="text-2xl font-bold text-green-600">2ms</p>
            <p className="text-sm text-gray-600">Avg Response Time</p>
          </div>
          <div className="text-center p-4 bg-purple-50 rounded-lg">
            <p className="text-2xl font-bold text-purple-600">45MB</p>
            <p className="text-sm text-gray-600">Memory Usage</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StatsView;
