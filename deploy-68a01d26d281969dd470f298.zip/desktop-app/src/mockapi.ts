// Mock API for browser-only version
export interface AdBlockerConfig {
  dns_enabled: boolean;
  browser_extension_enabled: boolean;
  system_blocking_enabled: boolean;
  streaming_blocking_enabled: boolean;
  auto_update_enabled: boolean;
  blocked_domains: Array<{
    domain: string;
    category: string;
    blocked_count: number;
    last_blocked: string;
  }>;
  whitelist: Array<{
    domain: string;
    added_date: string;
    reason: string;
  }>;
}

// Mock data
const mockConfig: AdBlockerConfig = {
  dns_enabled: true,
  browser_extension_enabled: true,
  system_blocking_enabled: false,
  streaming_blocking_enabled: true,
  auto_update_enabled: true,
  blocked_domains: [
    {
      domain: "doubleclick.net",
      category: "advertising",
      blocked_count: 1247,
      last_blocked: new Date().toISOString()
    },
    {
      domain: "googleadservices.com",
      category: "advertising", 
      blocked_count: 892,
      last_blocked: new Date().toISOString()
    },
    {
      domain: "facebook.com",
      category: "tracking",
      blocked_count: 654,
      last_blocked: new Date().toISOString()
    },
    {
      domain: "googlesyndication.com",
      category: "advertising",
      blocked_count: 543,
      last_blocked: new Date().toISOString()
    },
    {
      domain: "amazon-adsystem.com",
      category: "advertising",
      blocked_count: 432,
      last_blocked: new Date().toISOString()
    }
  ],
  whitelist: [
    {
      domain: "github.com",
      added_date: new Date().toISOString(),
      reason: "Development platform"
    },
    {
      domain: "stackoverflow.com",
      added_date: new Date().toISOString(),
      reason: "Learning resource"
    }
  ]
};

let currentConfig = { ...mockConfig };

// Mock API functions
export const mockApi = {
  get_config: async (): Promise<AdBlockerConfig> => {
    await new Promise(resolve => setTimeout(resolve, 500)); // Simulate delay
    return { ...currentConfig };
  },

  update_config: async (newConfig: AdBlockerConfig): Promise<void> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    currentConfig = { ...newConfig };
  },

  add_to_whitelist: async (domain: string, reason: string): Promise<void> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    currentConfig.whitelist.push({
      domain,
      added_date: new Date().toISOString(),
      reason
    });
  },

  remove_from_whitelist: async (domain: string): Promise<void> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    currentConfig.whitelist = currentConfig.whitelist.filter(entry => entry.domain !== domain);
  },

  get_blocked_stats: async (): Promise<Record<string, number>> => {
    await new Promise(resolve => setTimeout(resolve, 400));
    const totalBlocked = currentConfig.blocked_domains.reduce((sum, domain) => sum + domain.blocked_count, 0);
    
    return {
      total_blocked: totalBlocked,
      domains_blocked: currentConfig.blocked_domains.length,
      whitelist_entries: currentConfig.whitelist.length,
      category_advertising: currentConfig.blocked_domains
        .filter(d => d.category === 'advertising')
        .reduce((sum, d) => sum + d.blocked_count, 0),
      category_tracking: currentConfig.blocked_domains
        .filter(d => d.category === 'tracking')
        .reduce((sum, d) => sum + d.blocked_count, 0),
      category_malware: currentConfig.blocked_domains
        .filter(d => d.category === 'malware')
        .reduce((sum, d) => sum + d.blocked_count, 0)
    };
  },

  start_dns_server: async (): Promise<string> => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    return "DNS server started on 127.0.0.1:53 (Mock Mode)";
  },

  stop_dns_server: async (): Promise<string> => {
    await new Promise(resolve => setTimeout(resolve, 500));
    return "DNS server stopped (Mock Mode)";
  },

  update_blocklists: async (): Promise<string> => {
    await new Promise(resolve => setTimeout(resolve, 2000));
    // Add some new mock blocked domains
    const newDomains = [
      {
        domain: "ads.yahoo.com",
        category: "advertising",
        blocked_count: Math.floor(Math.random() * 100) + 10,
        last_blocked: new Date().toISOString()
      }
    ];
    currentConfig.blocked_domains.push(...newDomains);
    return "Blocklists updated successfully (Mock Mode)";
  }
};

// Check if we're in Tauri environment
export const isTauri = () => {
  return typeof window !== 'undefined' && window.__TAURI__ !== undefined;
};
