// Prevents additional console window on Windows in release, DO NOT REMOVE!!
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::fs;
use std::path::PathBuf;
use tauri::{Manager, State};
use tokio::sync::Mutex;

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct BlockedDomain {
    pub domain: String,
    pub category: String,
    pub blocked_count: u64,
    pub last_blocked: String,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct WhitelistEntry {
    pub domain: String,
    pub added_date: String,
    pub reason: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct AdBlockerConfig {
    pub dns_enabled: bool,
    pub browser_extension_enabled: bool,
    pub system_blocking_enabled: bool,
    pub streaming_blocking_enabled: bool,
    pub auto_update_enabled: bool,
    pub blocked_domains: Vec<BlockedDomain>,
    pub whitelist: Vec<WhitelistEntry>,
}

impl Default for AdBlockerConfig {
    fn default() -> Self {
        Self {
            dns_enabled: true,
            browser_extension_enabled: true,
            system_blocking_enabled: false,
            streaming_blocking_enabled: true,
            auto_update_enabled: true,
            blocked_domains: Vec::new(),
            whitelist: Vec::new(),
        }
    }
}

type ConfigState = Mutex<AdBlockerConfig>;

#[tauri::command]
async fn get_config(config: State<'_, ConfigState>) -> Result<AdBlockerConfig, String> {
    let config = config.lock().await;
    Ok(config.clone())
}

#[tauri::command]
async fn update_config(
    new_config: AdBlockerConfig,
    config: State<'_, ConfigState>,
) -> Result<(), String> {
    let mut config = config.lock().await;
    *config = new_config;
    save_config(&config).await.map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
async fn add_to_whitelist(
    domain: String,
    reason: String,
    config: State<'_, ConfigState>,
) -> Result<(), String> {
    let mut config = config.lock().await;
    let entry = WhitelistEntry {
        domain,
        added_date: chrono::Utc::now().to_rfc3339(),
        reason,
    };
    config.whitelist.push(entry);
    save_config(&config).await.map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
async fn remove_from_whitelist(
    domain: String,
    config: State<'_, ConfigState>,
) -> Result<(), String> {
    let mut config = config.lock().await;
    config.whitelist.retain(|entry| entry.domain != domain);
    save_config(&config).await.map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
async fn get_blocked_stats(config: State<'_, ConfigState>) -> Result<HashMap<String, u64>, String> {
    let config = config.lock().await;
    let mut stats = HashMap::new();
    
    let total_blocked: u64 = config.blocked_domains.iter().map(|d| d.blocked_count).sum();
    stats.insert("total_blocked".to_string(), total_blocked);
    stats.insert("domains_blocked".to_string(), config.blocked_domains.len() as u64);
    stats.insert("whitelist_entries".to_string(), config.whitelist.len() as u64);
    
    // Category breakdown
    let mut category_counts = HashMap::new();
    for domain in &config.blocked_domains {
        *category_counts.entry(domain.category.clone()).or_insert(0u64) += domain.blocked_count;
    }
    
    for (category, count) in category_counts {
        stats.insert(format!("category_{}", category), count);
    }
    
    Ok(stats)
}

#[tauri::command]
async fn start_dns_server() -> Result<String, String> {
    // This would start the local DNS server
    // For now, return a success message
    Ok("DNS server started on 127.0.0.1:53".to_string())
}

#[tauri::command]
async fn stop_dns_server() -> Result<String, String> {
    // This would stop the local DNS server
    Ok("DNS server stopped".to_string())
}

#[tauri::command]
async fn update_blocklists() -> Result<String, String> {
    // This would fetch and update the blocklists
    // For now, simulate an update
    tokio::time::sleep(tokio::time::Duration::from_secs(2)).await;
    Ok("Blocklists updated successfully".to_string())
}

async fn save_config(config: &AdBlockerConfig) -> Result<(), Box<dyn std::error::Error>> {
    let config_dir = get_config_dir()?;
    fs::create_dir_all(&config_dir)?;
    
    let config_path = config_dir.join("config.json");
    let config_json = serde_json::to_string_pretty(config)?;
    fs::write(config_path, config_json)?;
    
    Ok(())
}

async fn load_config() -> Result<AdBlockerConfig, Box<dyn std::error::Error>> {
    let config_dir = get_config_dir()?;
    let config_path = config_dir.join("config.json");
    
    if config_path.exists() {
        let config_json = fs::read_to_string(config_path)?;
        let config: AdBlockerConfig = serde_json::from_str(&config_json)?;
        Ok(config)
    } else {
        Ok(AdBlockerConfig::default())
    }
}

fn get_config_dir() -> Result<PathBuf, Box<dyn std::error::Error>> {
    let mut path = dirs::config_dir().ok_or("Could not find config directory")?;
    path.push("CrossGuard");
    Ok(path)
}

fn main() {
    tauri::Builder::default()
        .setup(|app| {
            let config = tauri::async_runtime::block_on(async {
                load_config().await.unwrap_or_default()
            });
            app.manage(ConfigState::new(config));
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            get_config,
            update_config,
            add_to_whitelist,
            remove_from_whitelist,
            get_blocked_stats,
            start_dns_server,
            stop_dns_server,
            update_blocklists
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
