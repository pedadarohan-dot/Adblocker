const Service = require('node-windows').Service;
const path = require('path');

// Create a new service object
const svc = new Service({
  name: 'CrossGuard DNS Server',
  description: 'CrossGuard DNS-based ad blocker service',
  script: path.join(__dirname, 'server.js'),
  nodeOptions: [
    '--harmony',
    '--max_old_space_size=4096'
  ]
});

// Listen for the "install" event, which indicates the process is available as a service.
svc.on('install', function() {
  console.log('CrossGuard DNS Server installed as Windows service');
  console.log('Starting service...');
  svc.start();
});

svc.on('alreadyinstalled', function() {
  console.log('CrossGuard DNS Server is already installed as a service');
});

svc.on('start', function() {
  console.log('CrossGuard DNS Server started successfully');
  console.log('Service is now running in the background');
});

// Install the script as a service.
console.log('Installing CrossGuard DNS Server as Windows service...');
svc.install();
