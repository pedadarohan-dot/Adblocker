# CrossGuard DNS Server

A standalone Rust-based DNS server that blocks ads at the network level for ALL applications.

## What It Blocks

✅ **Desktop Apps** - Spotify, Discord, games, any Windows app  
✅ **Mobile Apps** - When connected to your WiFi  
✅ **Web Browsers** - All websites  
✅ **Smart TVs** - YouTube ads, streaming ads  
✅ **Network-wide** - Every device on your network  

## Installation & Usage

### 1. Install Rust (Required)
```bash
# Download from: https://rustup.rs/
# Or direct: https://win.rustup.rs/x86_64
```

### 2. Build and Run
```bash
cd dns-server
cargo build --release
cargo run
```

### 3. Configure Your System DNS
**Windows:**
```bash
# Set DNS to use our server
netsh interface ip set dns "Wi-Fi" static 127.0.0.1
```

**Or manually:**
1. Open Network Settings
2. Change adapter options  
3. Right-click your connection → Properties
4. Select IPv4 → Properties
5. Use DNS server: `127.0.0.1`

## Features

- **16+ ad networks blocked** including Google Ads, Facebook, Amazon
- **Spotify ad blocking** - Blocks audio ads in desktop app
- **YouTube ad blocking** - Network-level blocking
- **Real-time statistics** - Shows blocked count in console
- **Upstream DNS forwarding** - Uses 8.8.8.8 for legitimate requests
- **Subdomain blocking** - Blocks *.doubleclick.net automatically

## Blocked Domains Include:
- doubleclick.net (Google Ads)
- googleadservices.com
- amazon-adsystem.com  
- adeventtracker.spotify.com (Spotify ads)
- facebook.com/tr (Facebook tracking)
- google-analytics.com
- And many more...

## Command Line Options
```bash
cargo run -- --bind 127.0.0.1 --port 53 --upstream 8.8.8.8
```

This DNS server will block ads in **ALL applications** including Spotify desktop, mobile apps, and streaming services!
