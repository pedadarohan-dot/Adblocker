const dns2 = require('dns2');
const express = require('express');
const cors = require('cors');
const fs = require('fs-extra');
const path = require('path');
const chalk = require('chalk');
const { program } = require('commander');

// Configuration
const CONFIG = {
  DNS_PORT: 53,
  HTTP_PORT: 3001,
  UPSTREAM_DNS: '8.8.8.8',
  BIND_ADDRESS: '0.0.0.0'
};

// Comprehensive blocked domains list
const BLOCKED_DOMAINS = new Set([
  // Google Ads & Analytics
  'doubleclick.net',
  'googleadservices.com',
  'googlesyndication.com',
  'google-analytics.com',
  'googletagmanager.com',
  'googletagservices.com',
  'adsystem.amazon.com',
  'amazon-adsystem.com',
  
  // Facebook/Meta Ads & Tracking
  'facebook.com',
  'connect.facebook.net',
  'instagram.com',
  'fbcdn.net',
  
  // Spotify Ads (Desktop App)
  'adeventtracker.spotify.com',
  'ads-fa.spotify.com',
  'analytics.spotify.com',
  'audio-ak-spotify-com.akamaized.net',
  'crashdump.spotify.com',
  'log.spotify.com',
  'omaze.spotify.com',
  'pubads.g.doubleclick.net',
  'securepubads.g.doubleclick.net',
  'spclient.wg.spotify.com',
  
  // YouTube Ads
  'googlevideo.com',
  'youtube.com',
  'ytimg.com',
  'googleusercontent.com',
  
  // Twitch Ads
  'ttvnw.net',
  'twitch.tv',
  'jtvnw.net',
  
  // Common Ad Networks
  'outbrain.com',
  'taboola.com',
  'criteo.com',
  'advertising.com',
  'ads.yahoo.com',
  'adsystem.amazon.de',
  'adsystem.amazon.co.uk',
  'amazon.adsystem.amazon.com',
  
  // Mobile Ad Networks
  'admob.com',
  'unity3d.com',
  'unityads.unity3d.com',
  'gameanalytics.com',
  'applovin.com',
  'ironsrc.com',
  'vungle.com',
  
  // Tracking & Analytics
  'hotjar.com',
  'mixpanel.com',
  'segment.com',
  'amplitude.com',
  'fullstory.com',
  'loggly.com',
  'bugsnag.com',
  'sentry.io',
  
  // Social Media Trackers
  'twitter.com',
  't.co',
  'linkedin.com',
  'pinterest.com',
  'snapchat.com',
  'tiktok.com',
  
  // Gaming Ad Networks
  'chartboost.com',
  'tapjoy.com',
  'supersonic.com',
  'fyber.com',
  'mintegral.com'
]);

// Statistics
let stats = {
  totalBlocked: 0,
  blockedDomains: new Map(),
  startTime: Date.now(),
  lastReset: Date.now()
};

// Whitelist for user exceptions
let whitelist = new Set();

// DNS Server
const dnsServer = dns2.createServer({
  udp: true,
  tcp: true,
  handle: (request, send, rinfo) => {
    const [question] = request.questions;
    const { name, type } = question;
    const domain = name.toLowerCase();
    
    console.log(chalk.blue(`DNS Query: ${domain} (${dns2.Packet.TYPE[type]})`));
    
    // Check whitelist first
    if (isWhitelisted(domain)) {
      console.log(chalk.green(`Whitelisted: ${domain}`));
      return forwardDNS(request, send, rinfo);
    }
    
    // Check if domain should be blocked
    if (shouldBlockDomain(domain)) {
      stats.totalBlocked++;
      stats.blockedDomains.set(domain, (stats.blockedDomains.get(domain) || 0) + 1);
      
      console.log(chalk.red(`BLOCKED: ${domain} (Total: ${stats.totalBlocked})`));
      
      // Return NXDOMAIN (domain doesn't exist)
      const response = dns2.Packet.createResponseFromRequest(request);
      response.header.rcode = dns2.Packet.RCODE.NXDOMAIN;
      send(response);
      return;
    }
    
    // Forward to upstream DNS
    forwardDNS(request, send, rinfo);
  }
});

// Check if domain should be blocked
function shouldBlockDomain(domain) {
  // Direct match
  if (BLOCKED_DOMAINS.has(domain)) return true;
  
  // Check subdomains
  const parts = domain.split('.');
  for (let i = 1; i < parts.length; i++) {
    const parentDomain = parts.slice(i).join('.');
    if (BLOCKED_DOMAINS.has(parentDomain)) return true;
  }
  
  return false;
}

// Check if domain is whitelisted
function isWhitelisted(domain) {
  if (whitelist.has(domain)) return true;
  
  // Check parent domains
  const parts = domain.split('.');
  for (let i = 1; i < parts.length; i++) {
    const parentDomain = parts.slice(i).join('.');
    if (whitelist.has(parentDomain)) return true;
  }
  
  return false;
}

// Forward DNS request to upstream server
function forwardDNS(request, send, rinfo) {
  const client = new dns2.DNSOverUDP({
    nameServer: CONFIG.UPSTREAM_DNS,
    port: 53
  });
  
  client.resolve(request)
    .then(response => {
      send(response);
    })
    .catch(error => {
      console.error(chalk.red(`DNS Forward Error: ${error.message}`));
      const response = dns2.Packet.createResponseFromRequest(request);
      response.header.rcode = dns2.Packet.RCODE.SERVFAIL;
      send(response);
    });
}

// HTTP API Server for management
const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// API Routes
app.get('/api/stats', (req, res) => {
  const uptime = Date.now() - stats.startTime;
  const topBlocked = Array.from(stats.blockedDomains.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10);
  
  res.json({
    totalBlocked: stats.totalBlocked,
    uniqueDomains: stats.blockedDomains.size,
    uptime: uptime,
    uptimeFormatted: formatUptime(uptime),
    topBlockedDomains: topBlocked,
    blockedDomainsCount: BLOCKED_DOMAINS.size,
    whitelistCount: whitelist.size
  });
});

app.get('/api/blocked-domains', (req, res) => {
  res.json(Array.from(BLOCKED_DOMAINS));
});

app.get('/api/whitelist', (req, res) => {
  res.json(Array.from(whitelist));
});

app.post('/api/whitelist', (req, res) => {
  const { domain } = req.body;
  if (domain) {
    whitelist.add(domain.toLowerCase());
    saveWhitelist();
    res.json({ success: true, message: `Added ${domain} to whitelist` });
  } else {
    res.status(400).json({ success: false, message: 'Domain required' });
  }
});

app.delete('/api/whitelist/:domain', (req, res) => {
  const domain = req.params.domain.toLowerCase();
  whitelist.delete(domain);
  saveWhitelist();
  res.json({ success: true, message: `Removed ${domain} from whitelist` });
});

app.post('/api/reset-stats', (req, res) => {
  stats.totalBlocked = 0;
  stats.blockedDomains.clear();
  stats.lastReset = Date.now();
  res.json({ success: true, message: 'Statistics reset' });
});

// Utility functions
function formatUptime(ms) {
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  
  if (days > 0) return `${days}d ${hours % 24}h ${minutes % 60}m`;
  if (hours > 0) return `${hours}h ${minutes % 60}m ${seconds % 60}s`;
  if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
  return `${seconds}s`;
}

function saveWhitelist() {
  const whitelistPath = path.join(__dirname, 'whitelist.json');
  fs.writeJsonSync(whitelistPath, Array.from(whitelist), { spaces: 2 });
}

function loadWhitelist() {
  const whitelistPath = path.join(__dirname, 'whitelist.json');
  try {
    if (fs.existsSync(whitelistPath)) {
      const data = fs.readJsonSync(whitelistPath);
      whitelist = new Set(data);
      console.log(chalk.green(`Loaded ${whitelist.size} whitelisted domains`));
    }
  } catch (error) {
    console.warn(chalk.yellow(`Could not load whitelist: ${error.message}`));
  }
}

// Command line interface
program
  .option('-p, --port <port>', 'DNS server port', CONFIG.DNS_PORT)
  .option('-h, --http-port <port>', 'HTTP API port', CONFIG.HTTP_PORT)
  .option('-u, --upstream <dns>', 'Upstream DNS server', CONFIG.UPSTREAM_DNS)
  .option('-b, --bind <address>', 'Bind address', CONFIG.BIND_ADDRESS);

program.parse();
const options = program.opts();

// Update config with CLI options
CONFIG.DNS_PORT = parseInt(options.port) || CONFIG.DNS_PORT;
CONFIG.HTTP_PORT = parseInt(options.httpPort) || CONFIG.HTTP_PORT;
CONFIG.UPSTREAM_DNS = options.upstream || CONFIG.UPSTREAM_DNS;
CONFIG.BIND_ADDRESS = options.bind || CONFIG.BIND_ADDRESS;

// Start servers
async function startServers() {
  try {
    // Load whitelist
    loadWhitelist();
    
    // Start DNS server
    dnsServer.listen({
      udp: { port: CONFIG.DNS_PORT, address: CONFIG.BIND_ADDRESS },
      tcp: { port: CONFIG.DNS_PORT, address: CONFIG.BIND_ADDRESS }
    });
    
    // Start HTTP API server
    app.listen(CONFIG.HTTP_PORT, () => {
      console.log(chalk.green('\n🛡️  CrossGuard DNS Server Started!'));
      console.log(chalk.blue(`📡 DNS Server: ${CONFIG.BIND_ADDRESS}:${CONFIG.DNS_PORT}`));
      console.log(chalk.blue(`🌐 HTTP API: http://localhost:${CONFIG.HTTP_PORT}`));
      console.log(chalk.blue(`⬆️  Upstream DNS: ${CONFIG.UPSTREAM_DNS}`));
      console.log(chalk.yellow(`🚫 Blocking ${BLOCKED_DOMAINS.size} domains`));
      console.log(chalk.green(`✅ Whitelisted ${whitelist.size} domains`));
      console.log(chalk.cyan('\n📋 Configure your system DNS to use this server:'));
      console.log(chalk.white(`   Windows: netsh interface ip set dns "Wi-Fi" static ${CONFIG.BIND_ADDRESS === '0.0.0.0' ? '127.0.0.1' : CONFIG.BIND_ADDRESS}`));
      console.log(chalk.white(`   Manual: Set DNS to ${CONFIG.BIND_ADDRESS === '0.0.0.0' ? '127.0.0.1' : CONFIG.BIND_ADDRESS}\n`));
    });
    
    // Statistics logging
    setInterval(() => {
      if (stats.totalBlocked > 0) {
        console.log(chalk.magenta(`📊 Total blocked: ${stats.totalBlocked} | Unique domains: ${stats.blockedDomains.size}`));
      }
    }, 30000);
    
  } catch (error) {
    console.error(chalk.red(`❌ Failed to start servers: ${error.message}`));
    process.exit(1);
  }
}

// Graceful shutdown
process.on('SIGINT', () => {
  console.log(chalk.yellow('\n🛑 Shutting down CrossGuard DNS Server...'));
  saveWhitelist();
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log(chalk.yellow('\n🛑 Shutting down CrossGuard DNS Server...'));
  saveWhitelist();
  process.exit(0);
});

// Start the servers
startServers();
