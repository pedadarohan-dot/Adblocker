use std::collections::HashSet;
use std::net::{IpAddr, Ipv4Addr, SocketAddr};
use std::str::FromStr;
use std::sync::Arc;
use tokio::sync::RwLock;
use trust_dns_proto::op::{Header, MessageType, OpCode, ResponseCode};
use trust_dns_proto::rr::{Name, RData, Record, RecordType};
use trust_dns_server::authority::MessageResponseBuilder;
use trust_dns_server::proto::rr::rdata::A;
use trust_dns_server::server::RequestHandler;
use trust_dns_server::{ServerFuture, Store};
use clap::Parser;
use log::{info, warn, debug};

#[derive(Parser, Debug)]
#[command(author, version, about, long_about = None)]
struct Args {
    #[arg(short, long, default_value = "127.0.0.1")]
    bind: String,
    
    #[arg(short, long, default_value = "5353")]
    port: u16,
    
    #[arg(short, long, default_value = "8.8.8.8")]
    upstream: String,
}

// Blocked domains list
const BLOCKED_DOMAINS: &[&str] = &[
    // Advertising networks
    "doubleclick.net",
    "googleadservices.com",
    "googlesyndication.com",
    "amazon-adsystem.com",
    "facebook.com",
    "google-analytics.com",
    "googletagmanager.com",
    "adsystem.amazon.com",
    "ads.yahoo.com",
    "advertising.com",
    "outbrain.com",
    "taboola.com",
    "criteo.com",
    
    // Spotify ads
    "audio-ak-spotify-com.akamaized.net",
    "heads-ak-spotify-com.akamaized.net",
    "audio4-ak-spotify-com.akamaized.net",
    "adeventtracker.spotify.com",
    "ads-fa.spotify.com",
    "analytics.spotify.com",
    "audio-ak-spotify-com.akamaized.net",
    "crashdump.spotify.com",
    "log.spotify.com",
    "omaze.spotify.com",
    "pubads.g.doubleclick.net",
    "securepubads.g.doubleclick.net",
    "spclient.wg.spotify.com",
    "audio-ak-spotify-com.akamaized.net",
    
    // YouTube ads
    "googlevideo.com",
    "youtube.com",
    "ytimg.com",
    "googleusercontent.com",
    
    // Social media trackers
    "facebook.com",
    "connect.facebook.net",
    "instagram.com",
    "twitter.com",
    "t.co",
    
    // Common trackers
    "google-analytics.com",
    "googletagmanager.com",
    "hotjar.com",
    "mixpanel.com",
    "segment.com",
    "amplitude.com",
];

#[derive(Clone)]
pub struct AdBlockHandler {
    blocked_domains: Arc<RwLock<HashSet<String>>>,
    upstream_resolver: trust_dns_resolver::TokioAsyncResolver,
    blocked_count: Arc<RwLock<u64>>,
}

impl AdBlockHandler {
    pub async fn new(upstream: &str) -> Result<Self, Box<dyn std::error::Error>> {
        let mut blocked_domains = HashSet::new();
        
        // Add blocked domains
        for domain in BLOCKED_DOMAINS {
            blocked_domains.insert(domain.to_string());
            // Also block subdomains
            blocked_domains.insert(format!("*.{}", domain));
        }
        
        // Create upstream resolver
        let upstream_addr = format!("{}:53", upstream).parse()?;
        let mut config = trust_dns_resolver::config::ResolverConfig::new();
        config.add_name_server(trust_dns_resolver::config::NameServerConfig {
            socket_addr: upstream_addr,
            protocol: trust_dns_resolver::config::Protocol::Udp,
            tls_dns_name: None,
            trust_negative_responses: false,
            bind_addr: None,
        });
        
        let resolver = trust_dns_resolver::TokioAsyncResolver::tokio(
            config,
            trust_dns_resolver::config::ResolverOpts::default(),
        );
        
        Ok(AdBlockHandler {
            blocked_domains: Arc::new(RwLock::new(blocked_domains)),
            upstream_resolver: resolver,
            blocked_count: Arc::new(RwLock::new(0)),
        })
    }
    
    async fn is_blocked(&self, domain: &str) -> bool {
        let blocked_domains = self.blocked_domains.read().await;
        
        // Check exact match
        if blocked_domains.contains(domain) {
            return true;
        }
        
        // Check if any parent domain is blocked
        let parts: Vec<&str> = domain.split('.').collect();
        for i in 1..parts.len() {
            let parent_domain = parts[i..].join(".");
            if blocked_domains.contains(&parent_domain) {
                return true;
            }
        }
        
        false
    }
    
    async fn increment_blocked_count(&self) {
        let mut count = self.blocked_count.write().await;
        *count += 1;
        if *count % 10 == 0 {
            info!("Blocked {} ads so far", *count);
        }
    }
    
    pub async fn get_blocked_count(&self) -> u64 {
        *self.blocked_count.read().await
    }
}

#[async_trait::async_trait]
impl RequestHandler for AdBlockHandler {
    async fn handle_request<R: trust_dns_server::server::ResponseHandler>(
        &self,
        request: &trust_dns_server::server::Request,
        mut response_handle: R,
    ) -> trust_dns_server::server::ResponseInfo {
        let builder = MessageResponseBuilder::from_message_request(request);
        let mut header = Header::response_from_request(request.header());
        
        let query = request.query();
        let name = query.name();
        let query_type = query.query_type();
        
        debug!("DNS Query: {} {:?}", name, query_type);
        
        // Check if domain should be blocked
        if self.is_blocked(&name.to_string()).await {
            warn!("Blocking domain: {}", name);
            self.increment_blocked_count().await;
            
            // Return NXDOMAIN (domain doesn't exist)
            header.set_response_code(ResponseCode::NXDomain);
            let response = builder.build(header, &[], &[], &[], &[]);
            return response_handle.send_response(response).await;
        }
        
        // Forward to upstream DNS server
        match self.upstream_resolver.lookup(name.clone(), query_type).await {
            Ok(lookup) => {
                let mut answers = Vec::new();
                
                for record in lookup.record_iter() {
                    answers.push(record.clone());
                }
                
                header.set_response_code(ResponseCode::NoError);
                let response = builder.build(header, &answers, &[], &[], &[]);
                response_handle.send_response(response).await
            }
            Err(e) => {
                warn!("Upstream DNS error for {}: {}", name, e);
                header.set_response_code(ResponseCode::ServFail);
                let response = builder.build(header, &[], &[], &[], &[]);
                response_handle.send_response(response).await
            }
        }
    }
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    env_logger::init();
    let args = Args::parse();
    
    info!("Starting CrossGuard DNS Server");
    info!("Bind address: {}:{}", args.bind, args.port);
    info!("Upstream DNS: {}", args.upstream);
    info!("Blocking {} domains", BLOCKED_DOMAINS.len());
    
    let handler = AdBlockHandler::new(&args.upstream).await?;
    let handler_clone = handler.clone();
    
    // Print statistics every 30 seconds
    tokio::spawn(async move {
        let mut interval = tokio::time::interval(tokio::time::Duration::from_secs(30));
        loop {
            interval.tick().await;
            let count = handler_clone.get_blocked_count().await;
            info!("Total ads blocked: {}", count);
        }
    });
    
    let socket_addr = SocketAddr::new(
        IpAddr::V4(Ipv4Addr::from_str(&args.bind)?),
        args.port,
    );
    
    let mut server = ServerFuture::new(handler);
    server.register_socket(socket_addr);
    
    info!("CrossGuard DNS Server listening on {}", socket_addr);
    info!("Configure your system to use this DNS server:");
    info!("  Windows: Network Settings > Change adapter options > Properties > IPv4 > Use DNS: {}", socket_addr.ip());
    info!("  Or run: netsh interface ip set dns \"Wi-Fi\" static {}", socket_addr.ip());
    
    server.block_until_done().await?;
    
    Ok(())
}
