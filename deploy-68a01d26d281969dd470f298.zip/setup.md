# CrossGuard Setup Instructions

## Prerequisites

### 1. Install Node.js
- Download from: https://nodejs.org/
- Install the LTS version (includes npm)
- Verify installation: `node --version` and `npm --version`

### 2. Install Rust
- Download from: https://rustup.rs/
- Run the installer and follow instructions
- Verify installation: `rustc --version`

### 3. Install Tauri CLI
```bash
npm install -g @tauri-apps/cli
```

## Running the Application

### Option 1: Run everything together
```bash
# Install all dependencies
npm run install:all

# Start development servers
npm run dev
```

### Option 2: Run desktop app only
```bash
# Navigate to desktop app
cd desktop-app

# Install dependencies
npm install

# Start Tauri development server
npm run tauri:dev
```

## Building for Production

### Desktop App
```bash
cd desktop-app
npm run tauri:build
```

This will create installers in `desktop-app/src-tauri/target/release/bundle/`

## Troubleshooting

### Common Issues:
1. **"npm not found"** - Install Node.js
2. **"rustc not found"** - Install Rust
3. **Build errors** - Make sure all dependencies are installed
4. **Permission errors** - Run terminal as administrator

### System Requirements:
- Windows 10/11
- Node.js 16+ 
- Rust 1.60+
- 4GB RAM minimum
- 2GB free disk space
