# CrossGuard Browser Extension

A working ad blocker extension that blocks ads on websites including YouTube, Facebook, and general web ads.

## Installation Instructions

### Chrome/Edge Installation:
1. Open Chrome/Edge browser
2. Go to `chrome://extensions/` (or `edge://extensions/`)
3. Enable "Developer mode" (toggle in top right)
4. Click "Load unpacked"
5. Select the `browser-extension` folder: `C:\Users\pedad\CascadeProjects\AdBlocker\browser-extension`
6. The extension will appear in your toolbar

### Firefox Installation:
1. Open Firefox
2. Go to `about:debugging`
3. Click "This Firefox"
4. Click "Load Temporary Add-on"
5. Select the `manifest.json` file in the browser-extension folder

## Features

✅ **Web Ad Blocking** - Blocks common ad networks (Google Ads, DoubleClick, etc.)
✅ **YouTube Ad Skipping** - Automatically skips YouTube video ads
✅ **Facebook Ad Blocking** - Hides sponsored posts on Facebook
✅ **Real-time Statistics** - Shows blocked ads count in popup
✅ **Toggle On/Off** - Enable/disable blocking with one click
✅ **Domain Tracking** - Lists blocked domains in popup

## How It Works

1. **Network Blocking**: Uses Chrome's declarativeNetRequest API to block ad domains
2. **Content Blocking**: Removes ad elements from web pages using CSS selectors
3. **YouTube Integration**: Automatically clicks skip buttons and hides ad overlays
4. **Statistics**: Tracks and displays blocked ads in real-time

## Usage

1. Install the extension following instructions above
2. Visit any website with ads (YouTube, news sites, etc.)
3. Click the CrossGuard icon in toolbar to see statistics
4. Toggle protection on/off as needed

## Blocked Domains Include:
- doubleclick.net
- googleadservices.com  
- googlesyndication.com
- amazon-adsystem.com
- facebook.com/tr
- google-analytics.com
- And many more...

This extension works immediately after installation - no Rust or additional setup required!
