// CrossGuard Browser Extension - Popup Script

document.addEventListener('DOMContentLoaded', function() {
  const toggleSwitch = document.getElementById('toggleSwitch');
  const statusElement = document.getElementById('status');
  const blockedCountElement = document.getElementById('blockedCount');
  const domainsCountElement = document.getElementById('domainsCount');
  const blockedDomainsContainer = document.getElementById('blockedDomains');

  // Load initial state
  loadStats();
  loadToggleState();

  // Toggle switch event listener
  toggleSwitch.addEventListener('click', function() {
    chrome.runtime.sendMessage({action: 'toggleEnabled'}, function(response) {
      updateToggleState(response.enabled);
    });
  });

  function loadStats() {
    chrome.runtime.sendMessage({action: 'getStats'}, function(response) {
      if (response) {
        blockedCountElement.textContent = response.blockedCount || 0;
        domainsCountElement.textContent = response.blockedDomains ? response.blockedDomains.length : 0;
        
        // Display blocked domains
        displayBlockedDomains(response.blockedDomains || []);
      }
    });
  }

  function loadToggleState() {
    chrome.storage.local.get(['enabled'], function(result) {
      const enabled = result.enabled !== false; // Default to true
      updateToggleState(enabled);
    });
  }

  function updateToggleState(enabled) {
    if (enabled) {
      toggleSwitch.classList.add('enabled');
      statusElement.textContent = 'Protection Active';
      statusElement.className = 'status active';
    } else {
      toggleSwitch.classList.remove('enabled');
      statusElement.textContent = 'Protection Disabled';
      statusElement.className = 'status inactive';
    }
  }

  function displayBlockedDomains(domains) {
    blockedDomainsContainer.innerHTML = '';
    
    if (domains.length === 0) {
      blockedDomainsContainer.innerHTML = '<div style="text-align: center; color: #6b7280; font-size: 12px; padding: 8px;">No domains blocked yet</div>';
      return;
    }

    // Show only the first 10 domains to avoid clutter
    const displayDomains = domains.slice(0, 10);
    
    displayDomains.forEach(domain => {
      const domainElement = document.createElement('div');
      domainElement.className = 'domain-item';
      domainElement.textContent = domain;
      blockedDomainsContainer.appendChild(domainElement);
    });

    if (domains.length > 10) {
      const moreElement = document.createElement('div');
      moreElement.style.textAlign = 'center';
      moreElement.style.color = '#6b7280';
      moreElement.style.fontSize = '11px';
      moreElement.style.padding = '4px';
      moreElement.textContent = `+${domains.length - 10} more domains`;
      blockedDomainsContainer.appendChild(moreElement);
    }
  }

  // Refresh stats every 5 seconds
  setInterval(loadStats, 5000);
});
