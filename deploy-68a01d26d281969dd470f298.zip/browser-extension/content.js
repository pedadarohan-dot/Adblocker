// CrossGuard Browser Extension - Content Script

(function() {
  'use strict';

  // YouTube ad blocking selectors
  const YOUTUBE_AD_SELECTORS = [
    '.video-ads',
    '.ytp-ad-module',
    '.ytp-ad-overlay-container',
    '.ytp-ad-text-overlay',
    '.ytp-ad-player-overlay',
    '.ytp-ad-skip-button-container',
    '.ytp-ad-button-icon',
    '.ytp-ad-image-overlay',
    '.ytp-ad-text',
    '.ytp-ad-overlay-close-button',
    '[class*="ad-showing"]',
    '[id*="player-ads"]'
  ];

  // General ad blocking selectors
  const GENERAL_AD_SELECTORS = [
    '[class*="advertisement"]',
    '[class*="google-ads"]',
    '[class*="adsense"]',
    '[id*="google_ads"]',
    '[id*="advertisement"]',
    '.ad-container',
    '.ad-banner',
    '.ad-slot',
    '.sponsored',
    '[data-ad-slot]',
    '[data-google-ad-client]'
  ];

  // Social media ad selectors
  const SOCIAL_AD_SELECTORS = [
    '[data-testid="placementTracking"]', // Facebook
    '[data-promoted="true"]', // Twitter
    '.promoted-tweet',
    '[aria-label*="Sponsored"]',
    '[aria-label*="Advertisement"]'
  ];

  let blockedElements = 0;
  let observer;

  // Initialize ad blocker
  function init() {
    console.log('CrossGuard Content Script loaded');
    
    // Check if extension is enabled
    chrome.storage.local.get(['enabled'], function(result) {
      if (result.enabled !== false) {
        startBlocking();
      }
    });

    // Listen for enable/disable messages
    chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
      if (request.action === 'toggleBlocking') {
        if (request.enabled) {
          startBlocking();
        } else {
          stopBlocking();
        }
      }
    });
  }

  function startBlocking() {
    // Remove existing ads
    removeAds();
    
    // Set up mutation observer to catch dynamically loaded ads
    setupObserver();
    
    // YouTube specific blocking
    if (window.location.hostname.includes('youtube.com')) {
      blockYouTubeAds();
    }
    
    // Facebook specific blocking
    if (window.location.hostname.includes('facebook.com')) {
      blockFacebookAds();
    }
  }

  function stopBlocking() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
  }

  function removeAds() {
    const allSelectors = [
      ...YOUTUBE_AD_SELECTORS,
      ...GENERAL_AD_SELECTORS,
      ...SOCIAL_AD_SELECTORS
    ];

    allSelectors.forEach(selector => {
      try {
        const elements = document.querySelectorAll(selector);
        elements.forEach(element => {
          if (element && element.parentNode) {
            element.style.display = 'none !important';
            element.remove();
            blockedElements++;
          }
        });
      } catch (e) {
        // Ignore invalid selectors
      }
    });

    // Block by URL patterns in iframes and images
    blockByUrl();
  }

  function blockByUrl() {
    // Block ad iframes
    const iframes = document.querySelectorAll('iframe');
    iframes.forEach(iframe => {
      const src = iframe.src || '';
      if (isAdUrl(src)) {
        iframe.style.display = 'none !important';
        iframe.remove();
        blockedElements++;
      }
    });

    // Block ad images
    const images = document.querySelectorAll('img');
    images.forEach(img => {
      const src = img.src || '';
      if (isAdUrl(src)) {
        img.style.display = 'none !important';
        img.remove();
        blockedElements++;
      }
    });
  }

  function isAdUrl(url) {
    const adDomains = [
      'doubleclick.net',
      'googleadservices.com',
      'googlesyndication.com',
      'amazon-adsystem.com',
      'facebook.com/tr',
      'google-analytics.com',
      'googletagmanager.com',
      'outbrain.com',
      'taboola.com',
      'criteo.com'
    ];

    return adDomains.some(domain => url.includes(domain));
  }

  function setupObserver() {
    observer = new MutationObserver(function(mutations) {
      let shouldRemoveAds = false;
      
      mutations.forEach(function(mutation) {
        if (mutation.addedNodes.length > 0) {
          shouldRemoveAds = true;
        }
      });

      if (shouldRemoveAds) {
        // Debounce ad removal to avoid excessive processing
        setTimeout(removeAds, 100);
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  function blockYouTubeAds() {
    // Skip YouTube video ads automatically
    const skipAd = () => {
      const skipButton = document.querySelector('.ytp-ad-skip-button, .ytp-skip-ad-button');
      if (skipButton && skipButton.offsetParent !== null) {
        skipButton.click();
        console.log('CrossGuard: Skipped YouTube ad');
      }
    };

    // Check for skip button every 500ms
    setInterval(skipAd, 500);

    // Hide YouTube ad overlay
    const hideAdOverlay = () => {
      const adOverlay = document.querySelector('.ytp-ad-overlay-container');
      if (adOverlay) {
        adOverlay.style.display = 'none !important';
      }
    };

    setInterval(hideAdOverlay, 1000);
  }

  function blockFacebookAds() {
    // Facebook sponsored posts
    const fbAds = document.querySelectorAll('[data-pagelet="FeedUnit_0"], [data-pagelet*="FeedUnit"]');
    fbAds.forEach(ad => {
      const sponsoredText = ad.querySelector('[aria-label*="Sponsored"], [aria-label*="Advertisement"]');
      if (sponsoredText) {
        ad.style.display = 'none !important';
        ad.remove();
        blockedElements++;
      }
    });
  }

  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Report blocked elements count
  setInterval(() => {
    if (blockedElements > 0) {
      chrome.runtime.sendMessage({
        action: 'updateBlockedCount',
        count: blockedElements
      });
      blockedElements = 0; // Reset counter
    }
  }, 5000);

})();
