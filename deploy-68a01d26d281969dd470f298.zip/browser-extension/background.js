// CrossGuard Browser Extension - Background Script

// Ad blocking rules - common ad domains
const AD_DOMAINS = [
  'doubleclick.net',
  'googleadservices.com',
  'googlesyndication.com',
  'amazon-adsystem.com',
  'facebook.com/tr',
  'google-analytics.com',
  'googletagmanager.com',
  'adsystem.amazon.com',
  'ads.yahoo.com',
  'advertising.com',
  'adsystem.amazon.co.uk',
  'amazon.adsystem.amazon.com',
  'outbrain.com',
  'taboola.com',
  'criteo.com',
  'adsystem.amazon.de'
];

// YouTube ad blocking
const YOUTUBE_AD_SELECTORS = [
  '.video-ads',
  '.ytp-ad-module',
  '.ytp-ad-overlay-container',
  '.ytp-ad-text-overlay',
  '.ytp-ad-player-overlay'
];

// Statistics
let blockedCount = 0;
let blockedDomains = new Set();

// Initialize extension
chrome.runtime.onInstalled.addListener(() => {
  console.log('CrossGuard Ad Blocker installed');
  
  // Set up declarative net request rules
  setupBlockingRules();
  
  // Initialize storage
  chrome.storage.local.set({
    enabled: true,
    blockedCount: 0,
    blockedDomains: [],
    whitelist: []
  });
});

// Set up blocking rules
async function setupBlockingRules() {
  const rules = AD_DOMAINS.map((domain, index) => ({
    id: index + 1,
    priority: 1,
    action: { type: 'block' },
    condition: {
      urlFilter: `*://*.${domain}/*`,
      resourceTypes: ['script', 'image', 'xmlhttprequest', 'sub_frame']
    }
  }));

  try {
    // Remove existing rules
    const existingRules = await chrome.declarativeNetRequest.getDynamicRules();
    const ruleIds = existingRules.map(rule => rule.id);
    
    if (ruleIds.length > 0) {
      await chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: ruleIds
      });
    }

    // Add new rules
    await chrome.declarativeNetRequest.updateDynamicRules({
      addRules: rules
    });

    console.log(`Added ${rules.length} blocking rules`);
  } catch (error) {
    console.error('Error setting up blocking rules:', error);
  }
}

// Listen for declarative net request events to count blocked ads
chrome.declarativeNetRequest.onRuleMatchedDebug.addListener((info) => {
  const url = new URL(info.request.url);
  const domain = url.hostname;
  
  blockedCount++;
  blockedDomains.add(domain);
  
  // Update storage
  chrome.storage.local.set({
    blockedCount: blockedCount,
    blockedDomains: Array.from(blockedDomains)
  });
  
  // Update badge
  chrome.action.setBadgeText({
    text: blockedCount.toString(),
    tabId: info.request.tabId
  });
  
  chrome.action.setBadgeBackgroundColor({color: '#dc2626'});
  
  console.log(`Blocked: ${domain}`);
});

// Handle messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getStats') {
    sendResponse({
      blockedCount: blockedCount,
      blockedDomains: Array.from(blockedDomains)
    });
  }
  
  if (request.action === 'toggleEnabled') {
    chrome.storage.local.get(['enabled'], (result) => {
      const newState = !result.enabled;
      chrome.storage.local.set({enabled: newState});
      sendResponse({enabled: newState});
    });
    return true;
  }
});

// Update badge when tab changes
chrome.tabs.onActivated.addListener((activeInfo) => {
  chrome.action.setBadgeText({
    text: blockedCount > 0 ? blockedCount.toString() : '',
    tabId: activeInfo.tabId
  });
});
