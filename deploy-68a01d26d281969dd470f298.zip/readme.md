# CrossGuard - Universal Ad Blocker

A fully functional, cross-platform ad-blocking solution that works on Windows, macOS, Android, iOS, and Linux.

## Features

- **Multi-layer blocking**: Browser extension, system-level blocking, and DNS-level filtering
- **Domain filtering**: Updated blocklist with whitelist support
- **Streaming platform support**: Blocks ads on Spotify, YouTube, Twitch, Hulu without breaking playback
- **Cross-platform GUI**: Unified dashboard for all platforms
- **Privacy-first**: No data collection, local processing only
- **Automatic updates**: Secure, signed update channel for blocking rules
- **Bypass detection**: Advanced methods to avoid ad service detection

## Architecture

```
CrossGuard/
├── desktop-app/          # Tauri-based desktop application
├── browser-extension/    # WebExtension for browsers
├── dns-server/          # Local DNS filtering server
├── mobile/              # React Native mobile apps
├── system-blocker/      # OS-specific system integrations
├── shared/              # Shared libraries and utilities
├── blocklists/          # Ad/tracker domain lists
└── update-server/       # Rule update mechanism
```

## Installation

### Desktop
- Download the installer for your platform from releases
- Run the installer and follow setup instructions

### Browser Extension
- Install from Chrome Web Store or Firefox Add-ons
- Or load unpacked extension from `browser-extension/` folder

### Mobile
- Download from App Store (iOS) or Play Store (Android)
- Or build from source using React Native

## Usage

1. Launch the desktop app to access the unified dashboard
2. Configure blocking preferences and whitelist domains
3. Install browser extensions for web ad blocking
4. Enable DNS filtering for network-wide protection
5. Monitor blocked ads and adjust settings as needed

## Building from Source

See individual component README files for build instructions.

## License

MIT License - See LICENSE file for details
